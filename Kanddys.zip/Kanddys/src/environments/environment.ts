export const environment = {
	slug: 'dlicianthus'
};
